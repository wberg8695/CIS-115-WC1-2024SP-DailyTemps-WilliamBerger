﻿namespace DailyTemps
{
    partial class DailyTemps
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            instrLabel = new Label();
            sunLabel = new Label();
            monLabel = new Label();
            tuesLabel = new Label();
            wedLabel = new Label();
            thurLabel = new Label();
            friLabel = new Label();
            satLabel = new Label();
            monInput = new TextBox();
            sunInput = new TextBox();
            tuesInput = new TextBox();
            wedInput = new TextBox();
            thurInput = new TextBox();
            friInput = new TextBox();
            satInput = new TextBox();
            avgTempLabel = new Label();
            avgTempOutput = new Label();
            calcButton = new Button();
            SuspendLayout();
            // 
            // instrLabel
            // 
            instrLabel.AutoSize = true;
            instrLabel.Location = new Point(244, 52);
            instrLabel.Name = "instrLabel";
            instrLabel.Size = new Size(255, 20);
            instrLabel.TabIndex = 0;
            instrLabel.Text = "Enter the Daily Highest Temerpatures";
            // 
            // sunLabel
            // 
            sunLabel.AutoSize = true;
            sunLabel.Location = new Point(75, 112);
            sunLabel.Name = "sunLabel";
            sunLabel.Size = new Size(57, 20);
            sunLabel.TabIndex = 1;
            sunLabel.Text = "Sunday";
            // 
            // monLabel
            // 
            monLabel.AutoSize = true;
            monLabel.Location = new Point(162, 112);
            monLabel.Name = "monLabel";
            monLabel.Size = new Size(63, 20);
            monLabel.TabIndex = 2;
            monLabel.Text = "Monday";
            // 
            // tuesLabel
            // 
            tuesLabel.AutoSize = true;
            tuesLabel.Location = new Point(252, 112);
            tuesLabel.Name = "tuesLabel";
            tuesLabel.Size = new Size(63, 20);
            tuesLabel.TabIndex = 3;
            tuesLabel.Text = "Tuesday";
            // 
            // wedLabel
            // 
            wedLabel.AutoSize = true;
            wedLabel.Location = new Point(330, 112);
            wedLabel.Name = "wedLabel";
            wedLabel.Size = new Size(85, 20);
            wedLabel.TabIndex = 4;
            wedLabel.Text = "Wednesday";
            // 
            // thurLabel
            // 
            thurLabel.AutoSize = true;
            thurLabel.Location = new Point(428, 112);
            thurLabel.Name = "thurLabel";
            thurLabel.Size = new Size(68, 20);
            thurLabel.TabIndex = 5;
            thurLabel.Text = "Thursday";
            // 
            // friLabel
            // 
            friLabel.AutoSize = true;
            friLabel.Location = new Point(527, 112);
            friLabel.Name = "friLabel";
            friLabel.Size = new Size(49, 20);
            friLabel.TabIndex = 6;
            friLabel.Text = "Friday";
            // 
            // satLabel
            // 
            satLabel.AutoSize = true;
            satLabel.Location = new Point(610, 112);
            satLabel.Name = "satLabel";
            satLabel.Size = new Size(67, 20);
            satLabel.TabIndex = 7;
            satLabel.Text = "Saturday";
            // 
            // monInput
            // 
            monInput.Location = new Point(160, 153);
            monInput.Name = "monInput";
            monInput.Size = new Size(65, 27);
            monInput.TabIndex = 8;
            // 
            // sunInput
            // 
            sunInput.Location = new Point(70, 153);
            sunInput.Name = "sunInput";
            sunInput.Size = new Size(65, 27);
            sunInput.TabIndex = 9;
            // 
            // tuesInput
            // 
            tuesInput.Location = new Point(250, 153);
            tuesInput.Name = "tuesInput";
            tuesInput.Size = new Size(65, 27);
            tuesInput.TabIndex = 10;
            // 
            // wedInput
            // 
            wedInput.Location = new Point(340, 154);
            wedInput.Name = "wedInput";
            wedInput.Size = new Size(65, 27);
            wedInput.TabIndex = 11;
            // 
            // thurInput
            // 
            thurInput.Location = new Point(430, 154);
            thurInput.Name = "thurInput";
            thurInput.Size = new Size(65, 27);
            thurInput.TabIndex = 12;
            // 
            // friInput
            // 
            friInput.Location = new Point(520, 153);
            friInput.Name = "friInput";
            friInput.Size = new Size(65, 27);
            friInput.TabIndex = 13;
            // 
            // satInput
            // 
            satInput.Location = new Point(610, 153);
            satInput.Name = "satInput";
            satInput.Size = new Size(65, 27);
            satInput.TabIndex = 14;
            // 
            // avgTempLabel
            // 
            avgTempLabel.AutoSize = true;
            avgTempLabel.Location = new Point(295, 245);
            avgTempLabel.Name = "avgTempLabel";
            avgTempLabel.Size = new Size(152, 20);
            avgTempLabel.TabIndex = 15;
            avgTempLabel.Text = "Average Temperature";
            // 
            // avgTempOutput
            // 
            avgTempOutput.BorderStyle = BorderStyle.Fixed3D;
            avgTempOutput.Location = new Point(340, 280);
            avgTempOutput.Name = "avgTempOutput";
            avgTempOutput.Size = new Size(65, 27);
            avgTempOutput.TabIndex = 16;
            // 
            // calcButton
            // 
            calcButton.Location = new Point(297, 200);
            calcButton.Name = "calcButton";
            calcButton.Size = new Size(150, 30);
            calcButton.TabIndex = 17;
            calcButton.Text = "Calculate Average";
            calcButton.UseVisualStyleBackColor = true;
            calcButton.Click += CalcButton_Click;
            // 
            // DailyTemps
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(732, 333);
            Controls.Add(calcButton);
            Controls.Add(avgTempOutput);
            Controls.Add(avgTempLabel);
            Controls.Add(satInput);
            Controls.Add(friInput);
            Controls.Add(thurInput);
            Controls.Add(wedInput);
            Controls.Add(tuesInput);
            Controls.Add(sunInput);
            Controls.Add(monInput);
            Controls.Add(satLabel);
            Controls.Add(friLabel);
            Controls.Add(thurLabel);
            Controls.Add(wedLabel);
            Controls.Add(tuesLabel);
            Controls.Add(monLabel);
            Controls.Add(sunLabel);
            Controls.Add(instrLabel);
            Name = "DailyTemps";
            Text = "Daily Temperatures";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label instrLabel;
        private Label sunLabel;
        private Label monLabel;
        private Label tuesLabel;
        private Label wedLabel;
        private Label thurLabel;
        private Label friLabel;
        private Label satLabel;
        private TextBox monInput;
        private TextBox sunInput;
        private TextBox tuesInput;
        private TextBox wedInput;
        private TextBox thurInput;
        private TextBox friInput;
        private TextBox satInput;
        private Label avgTempLabel;
        private Label avgTempOutput;
        private Button calcButton;
    }
}
