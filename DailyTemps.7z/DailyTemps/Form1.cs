namespace DailyTemps
{
    public partial class DailyTemps : Form
    {
        public DailyTemps()
        {
            InitializeComponent();
        }

        private void CalcButton_Click(object sender, EventArgs e)
        {
            string sun = sunInput.Text, mon = monInput.Text, tues = tuesInput.Text;
            string wed = wedInput.Text, thur = thurInput.Text, fri = friInput.Text;
            string sat = satInput.Text, output;
            int sunInt = Convert.ToInt32(sun), monInt = Convert.ToInt32(mon);
            int tuesInt = Convert.ToInt32(tues), wedInt = Convert.ToInt32(wed);
            int thurInt = Convert.ToInt32(thur), friInt = Convert.ToInt32(fri);
            int satInt = Convert.ToInt32(sat), total, average;
            if (sunInt >= -20 && sunInt <= 130)
            {
                if (monInt >= -20 && monInt <= 130)
                {
                    if (tuesInt >= -20 && tuesInt <= 130)
                    {
                        if (wedInt >= -20 && wedInt <= 130)
                        {
                            if (thurInt >= -20 && thurInt <= 130)
                            {
                                if (friInt >= -20 && friInt <= 130)
                                {
                                    if (satInt >= -20 && satInt <= 130)
                                    {
                                        total = (sunInt + monInt + tuesInt + wedInt + thurInt + friInt + satInt);
                                        average = (total / 7);
                                        output = Convert.ToString(average);
                                        avgTempOutput.Text = output;
                                    }
                                    else avgTempOutput.Text = "Error";
                                }
                                else avgTempOutput.Text = "Error";
                            }
                            else avgTempOutput.Text = "Error";
                        }
                        else avgTempOutput.Text = "Error";
                    }
                    else avgTempOutput.Text = "Error";
                }
                else avgTempOutput.Text = "Error";
            }
            else avgTempOutput.Text = "Error";
        }
    }
}
